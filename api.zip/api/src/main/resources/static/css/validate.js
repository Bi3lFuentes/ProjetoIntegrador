// validate.js
(function () {
    'use strict';

    // Função para aplicar a máscara de telefone (simples)
    function applyPhoneMask(event) {
        const input = event.target;
        let value = input.value.replace(/\D/g, ''); // Remove tudo que não é dígito
        const dddMaxLength = 2;
        const firstPartMaxLength = 5; // Para (XX) XXXXX-...
        const secondPartMaxLength = 4; // Para ...-XXXX

        // Limita o comprimento total para DDD + 9 dígitos (celular) = 11 dígitos
        value = value.substring(0, dddMaxLength + firstPartMaxLength + secondPartMaxLength);

        let formattedValue = '';

        if (value.length > 0) {
            formattedValue = `(${value.substring(0, dddMaxLength)}`;
        }
        if (value.length > dddMaxLength) {
            const numberPart = value.substring(dddMaxLength);
            const isLikelyMobile9Digit = numberPart.length > 8; // (XX) + 9 dígitos = 11 total
            const currentFirstPartMaxLength = isLikelyMobile9Digit ? firstPartMaxLength : 4;

            formattedValue += `) ${numberPart.substring(0, currentFirstPartMaxLength)}`;
            if (numberPart.length > currentFirstPartMaxLength) {
                formattedValue += `-${numberPart.substring(currentFirstPartMaxLength, currentFirstPartMaxLength + secondPartMaxLength)}`;
            }
        }
        input.value = formattedValue;
    }

    // Função para validar o padrão do telefone
    function validatePhoneNumberPattern(inputElement) {
        const feedbackElement = inputElement.nextElementSibling;
        const originalFeedbackMessage = "Formato de telefone inválido. Use (XX) XXXXX-XXXX ou (XX) XXXX-XXXX.";
        const requiredFeedbackMessage = "O telefone é obrigatório.";

        const telefonePattern = /^\([1-9]{2}\)\s(?:9[1-9][0-9]{3}|[2-9][0-9]{3})-[0-9]{4}$/;
        const value = inputElement.value.trim();

        // Limpa validação anterior e restaura mensagem padrão (se houver feedback element)
        inputElement.classList.remove('is-invalid');
        inputElement.classList.remove('is-valid');
        if (feedbackElement && feedbackElement.classList.contains('invalid-feedback')) {
            feedbackElement.textContent = originalFeedbackMessage;
        }

        if (value === '') {
            if (inputElement.required) {
                inputElement.classList.add('is-invalid');
                if (feedbackElement && feedbackElement.classList.contains('invalid-feedback')) {
                    feedbackElement.textContent = requiredFeedbackMessage;
                }
                return false;
            }
            return true; // Válido se vazio e não obrigatório
        }

        if (!telefonePattern.test(value)) {
            inputElement.classList.add('is-invalid');
            // A mensagem de formato já foi restaurada acima ou é a padrão do HTML
            return false;
        }

        inputElement.classList.add('is-valid');
        return true;
    }

    // Função para inicializar a validação em um formulário específico
    function initializeFormValidation(formElement) {
        if (!formElement) {
            console.warn("Elemento de formulário não encontrado para inicializar validação.");
            return;
        }

        const telefoneInput = formElement.querySelector('#telefone');

        if (telefoneInput) {
            telefoneInput.addEventListener('input', applyPhoneMask);
            telefoneInput.addEventListener('blur', function () {
                validatePhoneNumberPattern(telefoneInput);
            });
        } else {
            console.warn("Campo #telefone não encontrado no formulário:", formElement.id);
        }


        formElement.addEventListener('submit', function (event) {
            let isFormOverallValid = true;

            // Validação do telefone no submit
            if (telefoneInput) {
                if (!validatePhoneNumberPattern(telefoneInput)) {
                    isFormOverallValid = false;
                }
            }

            // Validação de números negativos
            const numberFieldsToValidate = [
                { id: 'distancia_municipio', defaultMsg: 'A distância é obrigatória e não pode ser negativa.', negativeMsg: 'A distância não pode ser negativa.' },
                { id: 'numMaoObraFamiliar', defaultMsg: 'Número obrigatório e não pode ser negativo.', negativeMsg: 'O número de pessoas não pode ser negativo.' },
                { id: 'numContratadas', defaultMsg: 'Número obrigatório e não pode ser negativo.', negativeMsg: 'O número de pessoas não pode ser negativo.' },
                { id: 'mediaDiarias', defaultMsg: 'Média obrigatória e não pode ser negativa.', negativeMsg: 'A média de diárias não pode ser negativa.' }
            ];

            numberFieldsToValidate.forEach(fieldConfig => {
                const input = formElement.querySelector('#' + fieldConfig.id);
                if (input) {
                    const feedback = input.nextElementSibling;
                    input.classList.remove('is-invalid');
                    input.classList.remove('is-valid');

                    if (feedback && feedback.classList.contains('invalid-feedback')) {
                        feedback.textContent = fieldConfig.defaultMsg; // Restaura mensagem padrão
                    }

                    if (input.value !== '') { // Se o campo tem valor
                        if (parseFloat(input.value) < 0) {
                            input.classList.add('is-invalid');
                            if (feedback && feedback.classList.contains('invalid-feedback')) {
                                feedback.textContent = fieldConfig.negativeMsg;
                            }
                            isFormOverallValid = false;
                        } else {
                            // Se não for negativo, verificamos outras validades
                            if (input.checkValidity()) { // Verifica outras restrições HTML5 se houver
                                input.classList.add('is-valid');
                            } else {
                                input.classList.add('is-invalid'); // Marcado como inválido por input.checkValidity()
                                isFormOverallValid = false;
                            }
                        }
                    } else if (input.required) { // Se o campo está vazio mas é obrigatório
                        input.classList.add('is-invalid'); // Deixa a mensagem padrão de obrigatório
                        isFormOverallValid = false;

                        if (feedback && feedback.classList.contains('invalid-feedback')) {
                        }
                    }
                } else {
                    console.warn("Campo #" + fieldConfig.id + " não encontrado no formulário:", formElement.id);
                }
            });

            // Validação geral do Bootstrap
            // adiciona 'is-invalid' aos campos que falham na validação HTML5.
            if (!formElement.checkValidity()) {
                isFormOverallValid = false;
            }

            if (!isFormOverallValid) {
                event.preventDefault();
                event.stopPropagation();
            }

            formElement.classList.add('was-validated');
        }, false);
        console.log("Validação inicializada para o formulário:", formElement.id);
    }

    // chama a função de inicialização para os formulários desejados
    window.addEventListener('load', function () {
        // Para o formulário de CADASTRO (assumindo ID 'cadastroPropForm')
        const cadastroForm = document.getElementById('cadastroPropForm');
        if (cadastroForm) {
            initializeFormValidation(cadastroForm);
        } else {

        }

        // Para o formulário de EDIÇÃO (com ID 'editPropForm')
        const editarForm = document.getElementById('editPropForm');
        if (editarForm) {
            initializeFormValidation(editarForm);
        } else {

        }
    }, false);
})();