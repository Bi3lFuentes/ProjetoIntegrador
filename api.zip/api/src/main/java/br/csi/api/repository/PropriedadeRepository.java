package br.csi.api.repository;

import br.csi.api.model.Propriedade;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PropriedadeRepository extends JpaRepository<Propriedade, Long> {
    Optional<Propriedade> findById(Long id);
}
;