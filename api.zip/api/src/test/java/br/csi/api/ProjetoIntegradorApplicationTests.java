package br.csi.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
